# iqbot
Bot Probabilístíco usando ciclos azuis e rosas
